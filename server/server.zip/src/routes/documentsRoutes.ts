import { RequestHandler, Router } from "express";
import { Request, Response, NextFunction } from "express";
import { findUserBySessionId } from "../models/User";
import {
  getUserDocuments,
  downloadDocument,
} from "../controllers/admin/documentsController";

interface User {
  id: number;
  nom: string;
  email: string;
  role: string;
}

interface AuthenticatedRequest extends Request {
  user: User;
}

const router = Router();

// Middleware d'authentification
const authenticateRequest: RequestHandler = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const sessionId = req.headers.authorization?.split(" ")[1];

    if (!sessionId) {
      res.status(401).json({ error: "Non authentifié" });
      return;
    }

    const user = await findUserBySessionId(sessionId);

    if (!user) {
      res.status(401).json({ error: "Session invalide" });
      return;
    }

    // Attacher l'utilisateur à la requête
    (req as any).user = user;
    next();
  } catch (error) {
    console.error("Erreur d'authentification:", error);
    res.status(401).json({ error: "Non authentifié" });
  }
};

// Route pour récupérer les documents de l'utilisateur
router.get("/user", authenticateRequest, (req: Request, res: Response) => {
  getUserDocuments(req as AuthenticatedRequest, res);
});

// Route pour télécharger un document
router.get(
  "/download/:id",
  authenticateRequest,
  (req: Request, res: Response) => {
    downloadDocument(req as AuthenticatedRequest, res);
  }
);

export default router;
